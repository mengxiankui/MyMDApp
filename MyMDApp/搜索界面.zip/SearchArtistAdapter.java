package com.geely.pateo.multimedia.view;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.geely.pateo.multimedia.view.CircleImageView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by qg on 17-8-24.
 */

public class SearchArtistAdapter extends RecyclerView.Adapter<SearchArtistAdapter.ViewHolder> {
    private List<String> mDataSet = new ArrayList<String>();

    //构造器，接受数据集
    public SearchArtistAdapter() {
    }

    public void refreshData(List<String> data) {
        mDataSet.clear();
        if (null != data)
            mDataSet.addAll(data);
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //加载布局文件
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.kuwo_search_artist_item, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        //将数据填充到具体的view中
//        holder.imageView.
        holder.mTextView.setText(mDataSet.get(position));
    }

    @Override
    public int getItemCount() {
        return mDataSet.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        public CircleImageView imageView;
        public TextView mTextView;

        public ViewHolder(View itemView) {
            super(itemView);
            //由于itemView是item的布局文件，我们需要的是里面的textView，因此利用itemView.findViewById获
            // 取里面的textView实例，后面通过onBindViewHolder方法能直接填充数据到每一个textView了
            imageView = (CircleImageView) itemView.findViewById(R.id.id_artist_image_view);
            mTextView = (TextView) itemView.findViewById(R.id.id_artist_text_view);
        }
    }
}