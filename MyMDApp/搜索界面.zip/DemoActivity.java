package com.geely.pateo.multimedia.view;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by qg on 17-8-24.
 */

public class DemoActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        RecyclerView recyclerView = new RecyclerView(this);
        GridLayoutManager gridlayoutManager = new GridLayoutManager(this, 3);
        SearchArtistAdapter searchArtistAdapter = new SearchArtistAdapter();
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL_LIST));
        recyclerView.setLayoutManager(gridlayoutManager);
        recyclerView.setAdapter(searchArtistAdapter);
        recyclerView.addOnItemTouchListener(new RecyclerViewClickListener(this, recyclerView,
                new RecyclerViewClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
//                        Toast.makeText(MainActivity.this,"Click "+mData.get(position),Toast.LENGTH_SHORT).show();
                    }
                }));
    }
}
